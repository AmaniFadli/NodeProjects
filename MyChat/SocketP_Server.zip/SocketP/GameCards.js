const WebSocket = require('ws');
const PORT = 3002;
let usuarios = [];
let newUserId = 0;
const wss = new WebSocket.Server({ port:PORT });

var currentPlayerGame = 0;
let goodCardsList = [];

console.log('Game online');

wss.on('connection', (socket) => {
    const usuario = { socket: socket, name: null, id: newUserId++ , firstUser: false, score : 0, isReady :false};
    usuarios.push(usuario);

    if(usuarios.length == 1){
        usuario.firstUser = true;
    }

    //hay que saber uando acaba la partida, tambien sistema de turnos
    // hace rque solo se vea el icono del player que esta jugando

    socket.send("Hello World" + usuarios.length);
    
    socket.on('close', () => {
        console.log('Client disconnected');

        var jsonToSend = {
            messageType:"UserDisconnect",
            countUsersConnected: usuarios.length,
        }
        sendMessageToOthers(JSON.stringify(jsonToSend), socket);

        const index = usuarios.indexOf(socket);
        if(index !== -1){
            usuarios.splice(index, 1);
        }

        usuarios[0].firstUser = true
        var jsonToSend = {   
            messageType:"NewFistUser",
            userFirstUser:usuarios[0].firstUser
        }
        sendMessageToUser(JSON.stringify(jsonToSend), usuarios[0]);
    });

    socket.on('message', (message) => {
        //Recibe mensaje de UNITY en JSON 
        const messageJSON = JSON.parse(message);

        usuario.name = messageJSON.userName;

        switch (messageJSON.messageType) {

            case 'NewUserInGame':
                var jsonToSend = {
                    messageType: 'NewUserToUser',
                    userName:usuario.name,
                    userId: usuario.id,
                    userFirstUser: usuario.firstUser,
                    userScore: usuario.score,
                }
                sendMessageToUser(JSON.stringify(jsonToSend), socket);

                var jsonToSendOther =  {
                    messageType: 'NewUserToAll',
                    countUsersConnected: usuarios.length,
                    userName:usuario.name,
                    userId: usuario.id,
                    userFirstUser: usuario.firstUser,
                    userScore: usuario.score,
                }
                sendMessageToAll(JSON.stringify(jsonToSendOther), socket);
            break;
            case 'ChangePanel':
                
                let array = [];

                for (let i = 0; i < 20; i++){
                    array.push(i);
                }

                for (let i = array.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [array[i], array[j]] = [array[j], array[i]]; // Intercambiar elementos
                }

                var jsonToSend = {
                    messageType: 'ChangePanelUnity',
                    isPlaying: true,
                    arrayCards:array
                }
                sendMessageToAll(JSON.stringify(jsonToSend), socket);
            break;
            case 'UpdateCard':
                const cardIndex = messageJSON.cardIndex;

                // Envía el mensaje de actualización a todos los clientes
                var jsonToSend = {
                    messageType: 'UpdateCardUnity',
                    cardIndex: cardIndex
                }
                sendMessageToAll(JSON.stringify(jsonToSend), socket);
            break;
            case 'WrongCards':
                console.log("A");
                if(currentPlayerGame == usuarios.length-1){
                    console.log("B");
                    currentPlayerGame = 0;
                }
                else{
                    currentPlayerGame++;
                }
                
                console.log(usuarios.length);
                const Card1 = messageJSON.idCard1;
                const Card2 = messageJSON.idCard2;

                var jsonToSend = {
                    messageType: 'NextPlayerUnity',
                    currentPlayer: usuarios[currentPlayerGame].id,
                    currentPlayerName:usuario[currentPlayerGame].name,
                    card1:Card1,
                    card2:Card2,
                    isActive: true
                }
                if(usuarios.length == 1){
                    sendMessageToUser(JSON.stringify(jsonToSend), socket);
                }
                else{
                    sendMessageToAll(JSON.stringify(jsonToSend), socket);
                }
            break;
            case 'GoodCards':
                const idcard1 = messageJSON.idCard1;
                const idcard2 = messageJSON.idCard2;
                goodCardsList.push(idcard1)
                goodCardsList.push(idcard2)

                var jsonToSend = {
                    messageType: 'GoodCardsUnity',
                    activeCard:false
                }
                sendMessageToAll(JSON.stringify(jsonToSend), socket);
            break;
            case 'ScorePlayer':
                const score = messageJSON.score
                usuario.score = score
                
                var jsonToSend = {
                    messageType: 'ScorePlayerUnity',
                    userScore:usuario.score
                }
                sendMessageToUser(JSON.stringify(jsonToSend), socket);
            break;
            default:
                console.log('Incorrect Message:', messageJSON.messageType);
            break;
        }
    });
});

process.on('SIGINT', () =>{
    wss.close(() =>{
        process.exit(0);
    });
});

function sendMessageToOthers(message, senderSocket) {
    for (let i = 0; i < usuarios.length; i++) {
        if (usuarios[i].socket !== senderSocket) {
            usuarios[i].socket.send(message);
        }
    }
}

function sendMessageToAll(message, senderSocket){
    for (let i = 0; i < usuarios.length; i++) {
        usuarios[i].socket.send(message);  
    }
}

function sendMessageToUser(message, senderSocket){
    console.log("sent " + message);
    senderSocket.send(message);
}