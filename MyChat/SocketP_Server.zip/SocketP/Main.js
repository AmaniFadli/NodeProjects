const WebSocket = require('ws');
const PORT = 3000;
let usuarios = [];
let newUserId = 0;
const passAdmin = "laPatriServer"
const wss = new WebSocket.Server({ port:PORT });
const { spawn } = require('child_process');

var chatServerProcess = spawn('node', ['Xat.js']);
var gameServerProcess = spawn('node', ['GameCards.js']);
var shopServerProcess = spawn('node', ['Shop.js']);

gameServerProcess.stdout.on('data', (data) => {
    console.log(`gameServerProcess message:${data}`);
});

chatServerProcess.stdout.on('data', (data) => {
    console.log(`chatServerProcess message:${data}`);
});

shopServerProcess.stdout.on('data', (data) => {
    console.log(`shopServerProcess message:${data}`);
});
wss.on('connection', (socket) => {
    
    //creamos el nuevo susuario y lo añadimos al array
    const usuario = { socket: socket, name: null, id: newUserId, iconoCursor: null, position: { x: 0, y: 0 }, score:0};

    newUserId++;
    usuarios.push(usuario);

    chatServerProcess.on('connection', (code, signal) => {
        console.log(`El servidor de xat ha conectat`);
    });

    gameServerProcess.on('connection', (code, signal) => {
        console.log(`El servidor de joc ha conectat`);
    });

    shopServerProcess.on('connection', (code, signal) => {
        console.log(`El servidor de shop ha conectat`);
    });
    
    //cuando el usuario salga pasara esto
    socket.on('close', () => {

        //mandamos mensaje en forma de json para que el retso vea que se a desconectado
        var jsonToSend = {
            messageType:"UserDisconnect",
            userName:usuario.name,
            userID:usuario.id,      
            iconoCursor:usuario.iconoCursor,
            userScore:usuario.score
        }
        sendMessageToOthers(JSON.stringify(jsonToSend), socket);

        //lo eliminamos del array
        const index = usuarios.indexOf(usuario);
        if(index !== -1){
            usuarios.splice(index, 1);
        }
    });

    // pregjunatra  davir lo de el array de users y prk cuando se conecta otro su icno lo eprsigue.
    socket.on('message', (message) => {
        //Recibe el mensaje desde unity en forma de json
        const messageJSON = JSON.parse(message);
        const nameServer = messageJSON.nameServer
        //filtamos la infromacion del mesnaje
        switch(messageJSON.messageType){
            case 'PassAdmin':
                const adminPas = messageJSON.adminPassword
                var isAdmin = false
                usuario.name = "Admin"
                if(adminPas == passAdmin){
                    isAdmin = true
                }
                var jsonToSend ={
                    messageType:"AdminPass",
                    isLogin:isAdmin,
                    adminName: usuario.name
                }
                sendMessageToUser(JSON.stringify(jsonToSend),socket);
            break;
            case 'StartServer':
                if(nameServer == "Shop Server"){
                    shopServerProcess = spawn('node', ['Shop.js']);
                }
                else if(nameServer == "Game Server"){
                    gameServerProcess = spawn('node', ['GameCards.js']);   

                }
                else if(nameServer == "Xat Server"){
                    chatServerProcess = spawn('node', ['Xat.js']);
                }
                var jsonToSend ={
                    messageType:"StartServerUnity",
                    nameServerToUnity:nameServer
                }
                sendMessageToOthers(JSON.stringify(jsonToSend), socket);
            break;
            case 'StopServer':
                if(nameServer == "Shop Server"){
                    shopServerProcess.kill('SIGINT');
                }
                else if(nameServer == "Game Server"){
                    gameServerProcess.kill('SIGINT');
                }
                else if(nameServer == "Xat Server"){
                    chatServerProcess.kill('SIGINT');
                }
                var jsonToSend ={
                    messageType:"StopServerUnity",
                    nameServerToUnity:nameServer
                }
                sendMessageToOthers(JSON.stringify(jsonToSend), socket);
            break;
            case 'NewUser':
                //seteamos el nombre que eligio el nuevo usuario
                usuario.name = messageJSON.userName;
                usuario.iconoCursor = messageJSON.iconoCursor;

                console.log(usuario.name +" "+ usuario.iconoCursor);
                
                //info para el resto de usuarios
                var jsonToSend = {
                    messageType:"NewUserInfoToOther",
                    userName:usuario.name,
                    userID:usuario.id,   
                    userPosition:usuario.position,   
                    iconoCursor:usuario.iconoCursor,     
                    userScore:usuario.score
                }
                sendMessageToOthers(JSON.stringify(jsonToSend), socket);

                //info para el propio usuario
                var jsonToSendUser = {
                    messageType:"NewUserInfo",
                    userName:usuario.name,
                    userID:usuario.id,
                    iconoCursor:usuario.iconoCursor,
                    userScore:usuario.score
                }
                sendMessageToUser(JSON.stringify(jsonToSendUser), socket);
                //info del resto de conectados para el user que se acaba de conectar
                var usersConnected = [];

                for(var i = 0; i < usuarios.length; i++){
                    if(usuario.id != usuarios[i].id){
                        
                        console.log("Añadimos usuario  " + usuarios[i].id);
                        const otherUser = {
                            otherUserName: usuarios[i].name,
                            otherUserId: usuarios[i].id,
                            otherUserIconoCursor: usuarios[i].iconoCursor,
                            otherUserPosition: usuarios[i].position,
                            otherUserScore: usuarios[i].score
                        }
                        usersConnected.push(otherUser);
                    }else{
                        console.log("NO Añadimos usuario  " + usuarios[i].id);

                    }
                }

                var jsonToSendUserInfo = {
                    messageType:"UsersConnected",
                    users:usersConnected
                }
                
                sendMessageToUser(JSON.stringify(jsonToSendUserInfo), socket);
            break;
            //posicion del mouse
            case 'MousePosition':
                var jsonToSend = {
                    messageType:"MousePositionUnity",
                    userID:usuario.id,
                    position: messageJSON.userPosition,
                }
                sendMessageToOthers(JSON.stringify(jsonToSend), socket);
            break;
            default:
                console.log('Incorrect Message:', messageJSON.messageType);
            break;
        }
    });
});

function sendMessageToOthers(message, senderSocket) {
    for (let i = 0; i < usuarios.length; i++) {
        if (usuarios[i].socket !== senderSocket) {
            usuarios[i].socket.send(message);
        }
    }
}

function sendMessageToUser(message, senderSocket){
    console.log("sent " + message);
    senderSocket.send(message);
}