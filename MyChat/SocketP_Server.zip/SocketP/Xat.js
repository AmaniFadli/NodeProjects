const { Socket } = require('dgram');
const WebSocket = require('ws');
const PORT = 3001;
let usuarios = [];
let newUserId = 0;
const wss = new WebSocket.Server({ port:PORT });

console.log('Xat online');

wss.on('connection', (socket) => {
    
    //creamos el nuevo susuario y lo añadimos al array
    const usuario = { socket: socket, name: null, idServer: newUserId, iconoCursor: null, position: { x: 0, y: 0 }};
    newUserId++;
    usuarios.push(usuario);
    

    //cuando el usuario salga pasara esto
    socket.on('close', () => {

        //lo eliminamos del array
        const index = usuarios.indexOf(socket);
        if(index !== -1){
            usuarios.splice(index, 1);
        }
    });

    // pregjunatra  davir lo de el array de users y prk cuando se conecta otro su icno lo eprsigue.
    socket.on('message', (message) => {
        //Recibe el mensaje desde unity en forma de json
        const messageJSON = JSON.parse(message);
        //filtamos la infromacion del mesnaje

        switch(messageJSON.messageType){
                //mensajes para el chat comun
            case 'ChatMessage':
                var jsonToSend = {
                    messageType:"ChatMessageUnity",
                    userName:usuario.name,
                    text:messageJSON.text
                }
                sendMessageToOthers(JSON.stringify(jsonToSend), socket);

            break; 
            default:
                console.log('Incorrect Message:', messageJSON.messageType);
            break;
        }
    });
});

process.on('SIGINT', () =>{
    wss.close(() =>{
        process.exit(0);
    });
});

function sendMessageToOthers(message, senderSocket) {
    for (let i = 0; i < usuarios.length; i++) {
        if (usuarios[i].socket !== senderSocket) {
            usuarios[i].socket.send(message);
        }
    }
}

function sendMessageToUser(message, senderSocket){
    console.log("sent " + message);
    senderSocket.send(message);
}
